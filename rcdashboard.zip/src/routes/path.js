export const PATH_PUBLIC = {
    home: '/',
    register: '/register',
    login: '/login',
    forget: '/forget',
    unauthorized: '/unauthorized',
    notFound: '/404',
  };